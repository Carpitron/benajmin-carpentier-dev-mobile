//
//  Generated file. Do not edit.
//

#include "generated_plugin_registrant.h"


void RegisterPlugins(flutter::PluginRegistry* registry) {
}
